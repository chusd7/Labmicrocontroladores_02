#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

//_______ESTADOS DE LA FMS________


//ESTADOS DE INTENSIDAD    // Estos estados van a definir que tipo de tiempo debe estarse contando

int display = 0;
int Contador_interrupt=0;// Se encarga de contar los ciclos
int tiempos = 0;
int decenas = 0;
int unidades = 0;
int flag=0;
int segundos_display;
volatile int timer_count = 0;
void delay(unsigned int tiempo) {
	unsigned int i;
	unsigned int j;

	for(i=0;i<tiempo;i++)
	  for(j=0;j<1275;j++);
}


int rounds(float x) {
  if (x >= 0) {
    return (int)(x + 0.5);
  } else {
    return (int)(x - 0.5);
  }
}

//Esta funcion configura los relojes e habilita las interrupciones generales y timer0, ademas de hacer el prescaling de TCCR0B
void Timer_config(){ 
	TCCR0A = 0; // Modo normal
	TCCR0B = (1 << CS02) | (1 << CS00); // Prescaler de 1024
	TCNT0 = 0; // Inicializar contador en 0
	TIMSK = (1 << TOIE0); // Habilitar interrupción de overflow
	sei();

}
ISR(TIMER0_OVF_vect) {
	static uint16_t counter = 0;
	counter++;
  	if (timer_count > 0) { // Solo decrementar si no ha llegado a cero
		segundos_display = rounds(timer_count/31);
    	timer_count--;
		
  	}
	if (counter == 2) {
		counter = 0;
		flag = !flag; // Cambiar el valor del flag
	}

}



void cuenta_regresiva(int tiempos){
	display = tiempos;
	decenas = display / 10;
	unidades = display % 10;
	if (flag==0){
		if (decenas==0) // Si decenas=0
					{	
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( decenas==1) //  Si  decenas=1
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( decenas==2) //  Si  decenas=2
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( decenas==3) //  Si  decenas=3
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( decenas==4) //  Si  decenas=4
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( decenas==5) //  Si  decenas=5
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( decenas==6) //  Si  decenas=6
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if (decenas==7) //  Si  decenas=7
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( decenas==8) //  Si  decenas=8
					{
						PORTB |= (1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( decenas==9) //  Si  decenas=9
					{
						PORTB |= (1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB |= (1 << PB3);
					}
					//delay(1);
					PORTB ^= (1 << PB5); // Invertir el valor del bit 5 de PORTB
					//delay(100);
					//flag = !flag;
	}
	 
				
	else{
					if (unidades==0) // Si unidades=0
					{	
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( unidades==1) //  Si  unidades=1
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
						PORTB |= (1 << PB3);
					}
					else if ( unidades==2) //  Si  unidades=2
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB &= ~(1 << PB3);
					}
					else if ( unidades==3) //  Si  unidades=3
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( unidades==4) //  Si  unidades=4
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
						PORTB &= ~(1 << PB3);
					}
					else if ( unidades==5) //  Si  unidades=5
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
						PORTB |= (1 << PB3);
					}
					else if ( unidades==6) //  Si  unidades=6
					{
						PORTB &= ~(1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( unidades==7) //  Si  unidades=7
					{
						PORTB &= ~(1 << PB0);
						PORTB |= (1 << PB1);
						PORTB |= (1 << PB2);
						PORTB |= (1 << PB3);
					}
					else if ( unidades==8) //  Si  unidades=8
					{
						PORTB |= (1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
						PORTB &= ~(1 << PB3);
					}
					else if ( unidades==9) //  Si  unidades=9
					{
						PORTB |= (1 << PB0);
						PORTB &= ~(1 << PB1);
						PORTB &= ~(1 << PB2);
						PORTB &= ~(1 << PB3);
						PORTB |= (1 << PB3);
					}
					//delay(1);
					PORTB ^= (1 << PB5); // Invertir el valor del bit 5 de PORTB
					//delay(100);
					//flag = !flag;
	}	
				
}	
int main(void) //Funcion principal
{
	DDRB |= (1 << PB0) | (1 << PB1) | (1 << PB2) | (1 << PB3) | (1 << PB5);

	PORTB &= (1<<PB0)|(1<<PB1)|(1<<PB2)|(1<<PB3)|(1<<PB5); // Se entablecen los pines B3 y B4 como salidas
	//PORTD &= (0<<PD4) | (0<<PD5); // Se entablecen los pines D4 y D5 como salidas
	Timer_config();
	int num = 310; // Número a contar
  	timer_count = num; // Inicializar el contador con el valor del número

	sei();
	//PORTB |= (0 << PB1); // Poner en bajo el pin 0
	//PORTB |= (0 << PB2); // Poner en bajo el pin 2
	//PORTB |= (0 << PB3); // Poner en bajo el pin 3
	PORTB |= (0 << PB5); // Poner en bajo el pin 5

	
	

    //Loop forever
    while ( 1 )
    {
	//num++;
	cuenta_regresiva(segundos_display);		

	}
}


